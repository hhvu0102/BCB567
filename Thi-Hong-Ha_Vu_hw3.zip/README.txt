Author: Vu Thi-Hong-Ha
NetID: 851924086

This zip file includes a Python program to for constructing a superword array for a file of short reads in Fastq format.
Details about each step are stated in comments in the program.


To run the program on a Linux machine from command line (using Python 3), do:
	module load python
	python /path/to/Thi-Hong-Ha_Vu_hw3.py /path/to/fastq-file /path/to/model-file word-cut-level
Notes:
+ Model can only contain 0 or 1.
+ Model file can only contain one line.
+ Word cut level has to be non-negative.

