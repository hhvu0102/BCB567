Author: Vu Thi-Hong-Ha
NetID: 851924086

This zip file includes:
i) a Python program to calculate optimal local alignment between two DNA sequences.
Details about each step are stated in comments in the program.
ii) a test case, with sequence 1 named A.txt and sequence 2 named B.txt.


To run the program on a Linux machine from command line, do:
	module load python
	python /path/to/Thi-Hong-Ha_Vu_hw1.py /path/to/sequence1-fasta-file /path/to/sequence2-fasta-file bonusScore
Note: Bonus score has to be non-negative.


For example:
	module load python
	python /path/to/Thi-Hong-Ha_Vu_hw1.py /path/to/A.txt /path/to/B.txt 1

Expected output:

Sequence A: GATCGTAGAGTGAGACCTAGTGTTTG
    Length: 26
Sequence B: CTCGTAGGTGAGATTCCTAGTGCC
    Length: 24

          Match Score: 10
       Mismatch Score: -15
     Gap-Open Penalty: 40
Gap-Extension Penalty: 2
          Bonus Score: 1

    Alignment Score: 120 (104 + 16)
             Length: 22
 Start Position in A: 3
 Start Position in B: 2
   End Position in A: 22
   End Position in B: 22

   Number of Matches: 19
    Percent Identity: 86%
Number of Mismatches: 0
      Number of Gaps: 3

1             .    :    .    :
3         TCGTAGAGTGAGA  CCTAGTG
          ||||||-||||||--|||||||
2         TCGTAG GTGAGATTCCTAGTG
