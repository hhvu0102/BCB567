Author: Vu Thi-Hong-Ha
NetID: 851924086

This zip file includes:
i) a Python program to for constructing a superword array for a file of short reads in Fastq format.
Details about each step are stated in comments in the program.
ii) a test case: data_1000.fastq


To run the program on a Linux machine from command line (using Python 3), do:
	module load python
	python /path/to/Thi-Hong-Ha_Vu_hw2.py /path/to/fastq-file word-cut-level
Note: Word cut level has to be non-negative.


For example:
	module load python
	python /path/to/Thi-Hong-Ha_Vu_hw2.py /path/to/data_1000.fastq 3

Expected output:

k = 1; count(k) = 260081
k = 2; count(k) = 2442