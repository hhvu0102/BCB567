Author: Vu Thi-Hong-Ha
NetID: 851924086

This zip file includes a Python program to This assignment gives you an opportunity to produce a multiple sequence alignment without gaps from several files of DNA sequences in Fasta format.
Details about each step are stated in comments in the program.


To run the program on a Linux machine from command line (using Python 3), do:
	module load python
	python /path/to/Thi-Hong-Ha_Vu_hw4.py /path/to/fileOfFiles /path/to/model-file word-cut-level
Notes:
+ Model can only contain 0 or 1.
+ Model file can only contain one line.
+ Word cut level has to be non-negative.

